export const VARIATION_TYPE = 'audienceVariation'
export const VARIANT_TYPE = 'audienceVariant'
export const DEFAULT_TYPE = 'audienceDefault'
export const AUDIENCE_TYPE = 'audienceTargeting'

/** Who gets content that targets no one in particular. */
export const DEFAULT_LABEL = 'Default Audience'

export const WRAP_EVENT = 'custom.audienceVariants.wrap'
export const UNWRAP_EVENT = 'custom.audienceVariants.unwrap'
export const ADD_SECTION_EVENT = 'custom.audienceVariants.addSection'
export const REMOVE_SECTION_EVENT = 'custom.audienceVariants.removeSection'
export const CONVERT_SECTION_EVENT = 'custom.audienceVariants.convertSection'
export const SET_TARGETING_EVENT = 'custom.audienceVariants.setTargeting'
export const REPAIR_EVENT = 'custom.audienceVariants.repair'
