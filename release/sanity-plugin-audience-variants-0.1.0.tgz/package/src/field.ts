import {
  type ArrayDefinition,
  type BlockDefinition,
  defineArrayMember,
  defineField,
  type FieldDefinitionBase,
  type ObjectDefinition,
} from 'sanity'
import {AUDIENCE_TYPE, VARIATION_TYPE} from './constants'
import {AudienceVariantsPlugins, AudienceVariantsPluginsWithTables} from './PortableTextPlugins'

type ArrayMember = ReturnType<typeof defineArrayMember>

export type AudienceFieldOptions = FieldDefinitionBase &
  Pick<ObjectDefinition, 'name' | 'title' | 'description' | 'hidden' | 'readOnly' | 'initialValue'>

export type AudienceVariantsFieldOptions = Omit<ArrayDefinition, 'type' | 'of' | 'components'> &
  FieldDefinitionBase & {
    /** Overrides for the top-level text block member (styles, marks, lists…). */
    block?: Omit<BlockDefinition, 'type' | 'name'>
    /** Extra array members (images, other block objects) alongside text and variations. */
    of?: ArrayMember[]
    /**
     * Turn on Sanity's table editing. The schema must declare a `table` type
     * (table → rows → row → cells → cell → value) and `of` must include it.
     */
    tables?: boolean
  }

/**
 * A Portable Text field with audience variations enabled: text blocks plus
 * `audienceVariation`, with the editor plugin wired up.
 *
 * ```ts
 * fields: [defineAudienceVariantsField({name: 'body', title: 'Body'})]
 * ```
 */
export function defineAudienceVariantsField({
  block,
  of = [],
  tables = false,
  ...field
}: AudienceVariantsFieldOptions) {
  return defineField({
    ...field,
    type: 'array',
    of: [
      defineArrayMember({...block, type: 'block'}),
      defineArrayMember({type: VARIATION_TYPE}),
      ...of,
    ],
    components: {
      portableText: {plugins: tables ? AudienceVariantsPluginsWithTables : AudienceVariantsPlugins},
    },
  })
}

/**
 * Who a whole document is for: picks in each configured dimension, made the
 * same way as a variant in the body. Empty means the Default Audience (every
 * reader). Stored as `{_type: 'audienceTargeting', <dimension>[]…}`.
 *
 * ```ts
 * fields: [defineAudienceField({name: 'audience', title: 'Audience'})]
 * ```
 */
export function defineAudienceField(field: AudienceFieldOptions) {
  return defineField({...field, type: AUDIENCE_TYPE})
}
