import type {EditorSnapshot, Path, PortableTextBlock} from '@portabletext/editor'
import {defineBehavior, raise} from '@portabletext/editor/behaviors'
import {getSelectedBlocks, isSelectionCollapsed} from '@portabletext/editor/selectors'
import {createKeyboardShortcut} from '@portabletext/keyboard-shortcuts'
import {
  ADD_SECTION_EVENT,
  CONVERT_SECTION_EVENT,
  DEFAULT_TYPE,
  REMOVE_SECTION_EVENT,
  REPAIR_EVENT,
  SET_TARGETING_EVENT,
  UNWRAP_EVENT,
  VARIANT_TYPE,
  VARIATION_TYPE,
  WRAP_EVENT,
} from './constants'
import {getDefaultSection, isDefaultSection, type Section, type VariationValue} from './resolve'

/** Alt+Shift+V (Option+Shift+V on Mac). `code` so Option's special chars don't matter. */
export const wrapShortcut = createKeyboardShortcut({
  default: [{code: 'KeyV', alt: true, shift: true, ctrl: false, meta: false}],
})

type Keyed = {_key: string}

/**
 * Which `_type`s may live in a section: the text block, plus the object types
 * injected through the plugin's `content.of`.
 */
export type SectionTypes = {
  objectTypes: ReadonlySet<string>
  /** Dimension field names; a new variant starts with each one empty. */
  dimensions: readonly string[]
}

function allowedInSection(snapshot: EditorSnapshot, types: SectionTypes, type: string) {
  return type === snapshot.context.schema.block.name || types.objectTypes.has(type)
}

/**
 * Top-level blocks covered by the selection, or null if it covers anything a
 * section can't hold.
 */
function getWrappableBlocks(snapshot: EditorSnapshot, types: SectionTypes) {
  const selected = getSelectedBlocks(snapshot)
  if (selected.length === 0) return null
  // Path length 1 = top level; deeper means the selection is inside a variation.
  const ok = selected.every(
    ({node, path}) => path.length === 1 && allowedInSection(snapshot, types, node._type),
  )
  return ok ? selected : null
}

function findVariation(snapshot: EditorSnapshot, key: string) {
  return snapshot.context.value.find(
    (b): b is VariationValue & PortableTextBlock => b._key === key && b._type === VARIATION_TYPE,
  )
}

function emptyTextBlock(snapshot: EditorSnapshot): PortableTextBlock {
  return {
    _type: snapshot.context.schema.block.name,
    _key: snapshot.context.keyGenerator(),
    children: [{_type: 'span', _key: snapshot.context.keyGenerator(), text: '', marks: []}],
    markDefs: [],
    style: 'normal',
  }
}

function newSection(
  snapshot: EditorSnapshot,
  kind: 'default' | 'variant',
  types: SectionTypes,
): Section {
  const content = [emptyTextBlock(snapshot)]
  const _key = snapshot.context.keyGenerator()
  return kind === 'default'
    ? {_type: DEFAULT_TYPE, _key, content}
    : {_type: VARIANT_TYPE, _key, ...emptyPicks(types), content}
}

/** `{regions: [], audiences: []}`, with `picks` set in one dimension. */
function emptyPicks(types: SectionTypes, dimension?: string, picks: string[] = []) {
  return Object.fromEntries(types.dimensions.map((d) => [d, d === dimension ? picks : []]))
}

/** Caret at the start of a section's first block. */
function selectStartOf(sectionPath: Path, section: Section) {
  const block = section.content?.[0] as (PortableTextBlock & {children?: Keyed[]}) | undefined
  const span = block?.children?.[0]
  if (!block || !span) return []
  const path: Path = [...sectionPath, 'content', {_key: block._key}, 'children', {_key: span._key}]
  return [raise({type: 'select', at: {anchor: {path, offset: 0}, focus: {path, offset: 0}}})]
}

/**
 * Wrap the selected top-level blocks in a new variation; they become its
 * default section.
 */
const wrapSelection = (types: SectionTypes) =>
  defineBehavior({
    on: WRAP_EVENT,
    guard: ({snapshot}) => {
      const selected = getWrappableBlocks(snapshot, types)
      return selected ? {selected} : false
    },
    actions: [
      ({snapshot}, {selected}) => {
        const variation: VariationValue = {
          _type: VARIATION_TYPE,
          _key: snapshot.context.keyGenerator(),
          variants: [
            {
              _type: DEFAULT_TYPE,
              _key: snapshot.context.keyGenerator(),
              content: selected.map(({node}) => node),
            },
          ],
        }
        const first = selected[0].path
        return [
          raise({
            type: 'insert.block',
            block: variation,
            placement: 'before',
            select: 'none',
            at: {anchor: {path: first, offset: 0}, focus: {path: first, offset: 0}},
          }),
          ...selected.map(({path}) => raise({type: 'delete.block', at: path})),
        ]
      },
    ],
  })

const wrapOnShortcut = defineBehavior({
  on: 'keyboard.keydown',
  guard: ({event}) => wrapShortcut.guard(event.originEvent),
  actions: [() => [raise({type: WRAP_EVENT})]],
})

/**
 * The toolbar's "Audience variation" insert button wraps the selected text
 * instead of inserting an empty variation, so it does the same as the
 * shortcut. With a caret only, it inserts as before.
 */
const insertWrapsSelection = (types: SectionTypes) =>
  defineBehavior({
    on: 'insert.block',
    guard: ({snapshot, event}) => {
      if (event.block._type !== VARIATION_TYPE) return false
      const variants = (event.block as Partial<VariationValue>).variants
      if (Array.isArray(variants) && variants.length > 0) return false
      const selection = snapshot.context.selection
      if (!selection || isSelectionCollapsed(snapshot)) return false
      return getWrappableBlocks(snapshot, types) !== null
    },
    actions: [() => [raise({type: WRAP_EVENT})]],
  })

/**
 * A variation inserted empty (e.g. from the toolbar's insert menu) gets a
 * default section with one empty paragraph, so there is somewhere to type.
 */
const scaffoldInsertedVariation = (types: SectionTypes) =>
  defineBehavior({
    on: 'insert.block',
    guard: ({event}) => {
      if (event.block._type !== VARIATION_TYPE) return false
      const variants = (event.block as Partial<VariationValue>).variants
      return !(Array.isArray(variants) && variants.length > 0)
    },
    actions: [
      ({snapshot, event}) => [
        raise({...event, block: {...event.block, variants: [newSection(snapshot, 'default', types)]}}),
      ],
    ],
  })

/**
 * Replace a variation with its default content as plain blocks. Variants are
 * discarded (the UI confirms before sending this). No default = removed.
 */
const unwrapVariation = defineBehavior({
  on: UNWRAP_EVENT,
  guard: ({snapshot, event}) => {
    const block = findVariation(snapshot, (event as {key?: string}).key ?? '')
    if (!block) return false
    return {
      path: [{_key: block._key}] as Path,
      // Fresh keys: nested keys are only unique within their array and could
      // collide with keys already in the body.
      blocks: (getDefaultSection(block)?.content ?? []).map((b) => ({
        ...b,
        _key: snapshot.context.keyGenerator(),
      })),
    }
  },
  actions: [
    (_, {path, blocks}) => [
      ...(blocks.length
        ? [
            raise({
              type: 'insert.blocks',
              blocks,
              placement: 'after',
              select: 'none',
              at: {anchor: {path, offset: 0}, focus: {path, offset: 0}},
            }),
          ]
        : []),
      raise({type: 'delete.block', at: path}),
    ],
  ],
})

type TextBlock = PortableTextBlock & {
  children?: (Keyed & {marks?: string[]})[]
  markDefs?: Keyed[]
}

/**
 * Deep-copy blocks with fresh keys (blocks, spans and annotation defs, with
 * span marks remapped to the new def keys) so the copy can live in another
 * section without key collisions.
 */
function cloneBlocks(snapshot: EditorSnapshot, blocks: PortableTextBlock[]): PortableTextBlock[] {
  const key = () => snapshot.context.keyGenerator()
  return (blocks as TextBlock[]).map((block) => {
    const defKeys = new Map((block.markDefs ?? []).map((d) => [d._key, key()]))
    return {
      ...block,
      _key: key(),
      ...(block.markDefs && {
        markDefs: block.markDefs.map((d) => ({...d, _key: defKeys.get(d._key)!})),
      }),
      ...(block.children && {
        children: block.children.map((child) => ({
          ...child,
          _key: key(),
          ...(child.marks && {marks: child.marks.map((m) => defKeys.get(m) ?? m)}),
        })),
      }),
    }
  })
}

/**
 * Add a default or variant section to a variation. Order is variants first,
 * default last, so the block reads "these audiences get X, everyone else Y".
 * `copyFrom` seeds the new section with another section's content.
 */
const addSection = (types: SectionTypes) =>
  defineBehavior({
    on: ADD_SECTION_EVENT,
    guard: ({snapshot, event}) => {
      const {key, kind, copyFrom} = event as {
        key?: string
        kind?: 'default' | 'variant'
        copyFrom?: string
      }
      const block = findVariation(snapshot, key ?? '')
      if (!block || !kind) return false
      if (kind === 'default' && getDefaultSection(block)) return false
      const source = copyFrom ? block.variants?.find((s) => s._key === copyFrom) : undefined
      const section = newSection(snapshot, kind, types)
      if (source?.content?.length) section.content = cloneBlocks(snapshot, source.content)
      return {block, kind, section}
    },
    actions: [
      (_, {block, kind, section}) => {
        const variationPath: Path = [{_key: block._key}]
        const sections = block.variants ?? []
        const sectionPath: Path = [...variationPath, 'variants', {_key: section._key}]
        // Variants go after the last variant (or before the default if there are
        // none yet); a default goes at the end.
        const lastVariant = sections.filter((s) => !isDefaultSection(s)).at(-1)
        const fallback = getDefaultSection(block)
        const [anchor, position] =
          kind === 'variant' && lastVariant
            ? [lastVariant, 'after' as const]
            : kind === 'variant' && fallback
              ? [fallback, 'before' as const]
              : [sections.at(-1), 'after' as const]
        const insert = anchor
          ? raise({
              type: 'insert',
              at: [...variationPath, 'variants', {_key: anchor._key}],
              value: section,
              position,
            })
          : raise({type: 'set', at: [...variationPath, 'variants'], value: [section]})
        return [insert, ...selectStartOf(sectionPath, section)]
      },
    ],
  })

/** Remove one section; removing the last one removes the whole variation. */
const removeSection = defineBehavior({
  on: REMOVE_SECTION_EVENT,
  guard: ({snapshot, event}) => {
    const {key, sectionKey} = event as {key?: string; sectionKey?: string}
    const block = findVariation(snapshot, key ?? '')
    if (!block || !block.variants?.some((s) => s._key === sectionKey)) return false
    return {block, sectionKey: sectionKey!}
  },
  actions: [
    (_, {block, sectionKey}) => {
      const variationPath: Path = [{_key: block._key}]
      if ((block.variants ?? []).length <= 1) {
        return [raise({type: 'delete.block', at: variationPath})]
      }
      return [raise({type: 'unset', at: [...variationPath, 'variants', {_key: sectionKey}]})]
    },
  ],
})

/**
 * Swap a section between default and variant, keeping its key and content.
 * Picking an audience on the default sends this with `field`/`ids`, so the
 * default becomes a variant targeting them; readers no variant targets then
 * see nothing. A variant can only become the default when there isn't one.
 *
 * The whole `variants` array is set in one go: the section keeps its key, so
 * the caret and an open picker stay put.
 */
const convertSection = (types: SectionTypes) =>
  defineBehavior({
    on: CONVERT_SECTION_EVENT,
    guard: ({snapshot, event}) => {
      const {key, sectionKey, field, ids} = event as {
        key?: string
        sectionKey?: string
        field?: string
        ids?: string[]
      }
      const block = findVariation(snapshot, key ?? '')
      const section = block?.variants?.find((s) => s._key === sectionKey)
      if (!block || !section) return false
      if (field !== undefined && !types.dimensions.includes(field)) return false
      const toDefault = !isDefaultSection(section)
      if (toDefault && getDefaultSection(block)) return false
      const content = section.content?.length
        ? section.content
        : newSection(snapshot, 'default', types).content
      const replacement: Section = toDefault
        ? {_type: DEFAULT_TYPE, _key: section._key, content}
        : {
            _type: VARIANT_TYPE,
            _key: section._key,
            ...emptyPicks(types, field, ids),
            content,
          }
      // Keep the convention: variants first, the default last.
      const rest = (block.variants ?? []).filter((s) => s._key !== section._key)
      const variants = toDefault
        ? [...rest, replacement]
        : [...rest.filter((s) => !isDefaultSection(s)), replacement]
      return {at: [{_key: block._key}, 'variants'] as Path, variants}
    },
    actions: [(_, {at, variants}) => [raise({type: 'set', at, value: variants})]],
  })

/** Set a variant's picks in one dimension (the picker sends the whole list). */
const setTargeting = (types: SectionTypes) =>
  defineBehavior({
    on: SET_TARGETING_EVENT,
    guard: ({snapshot, event}) => {
      const {key, sectionKey, field, ids} = event as {
        key?: string
        sectionKey?: string
        field?: string
        ids?: string[]
      }
      const block = findVariation(snapshot, key ?? '')
      const section = block?.variants?.find((s) => s._key === sectionKey)
      if (!block || !section || isDefaultSection(section) || !ids) return false
      if (!field || !types.dimensions.includes(field)) return false
      return {
        at: [{_key: block._key}, 'variants', {_key: section._key}, field] as Path,
        ids,
      }
    },
    actions: [(_, {at, ids}) => [raise({type: 'set', at, value: ids})]],
  })

function isSection(node: {_type: string}): node is Section {
  return node._type === VARIANT_TYPE || node._type === DEFAULT_TYPE
}

/**
 * Whether any variation has members in `variants` that aren't sections. The
 * editor has been seen to leave a bare text block there after Enter/Backspace
 * inside a section; Sanity's form then crashes when the caret enters it
 * ("Cannot read properties of undefined (reading 'schemaType')").
 */
export function hasStrayVariantMembers(value: PortableTextBlock[] | undefined) {
  return (value ?? []).some(
    (b) =>
      b._type === VARIATION_TYPE &&
      ((b as VariationValue).variants ?? []).some((member) => !isSection(member)),
  )
}

/**
 * Move bare blocks found directly in a variation's `variants` back into a
 * section: the section above them, else the one below, else a new default.
 * Anything a section doesn't allow is removed. The caret follows a moved block.
 */
const repairVariations = (types: SectionTypes) =>
  defineBehavior({
    on: REPAIR_EVENT,
    guard: ({snapshot}) => {
      const block = snapshot.context.value.find(
        (b): b is VariationValue & PortableTextBlock =>
          b._type === VARIATION_TYPE &&
          ((b as VariationValue).variants ?? []).some((member) => !isSection(member)),
      )
      return block ? {block} : false
    },
    actions: [
      ({snapshot}, {block}) => {
        const allowed = (m: {_type: string}) => allowedInSection(snapshot, types, m._type)
        const variationPath: Path = [{_key: block._key}]
        const members = (block.variants ?? []) as (Section | PortableTextBlock)[]
        const sections = members.filter(isSection)
        const actions: ReturnType<typeof raise>[] = []
        // Where each moved block ends up, to carry the caret along.
        const moved = new Map<string, {sectionKey: string; blockKey: string}>()

        if (sections.length === 0) {
          const content = members.filter(allowed) as PortableTextBlock[]
          const section: Section = {
            _type: DEFAULT_TYPE,
            _key: snapshot.context.keyGenerator(),
            content,
          }
          content.forEach((b) => moved.set(b._key, {sectionKey: section._key, blockKey: b._key}))
          actions.push(raise({type: 'set', at: [...variationPath, 'variants'], value: [section]}))
        } else {
          let target: Section | undefined
          let anchor: {key: string; position: 'before' | 'after'} | undefined
          members.forEach((member, index) => {
            if (isSection(member)) {
              target = member
              const last = member.content?.at(-1)
              anchor = last ? {key: last._key, position: 'after'} : undefined
              return
            }
            const at: Path = [...variationPath, 'variants', {_key: member._key}]
            if (!allowed(member)) {
              actions.push(raise({type: 'unset', at}))
              return
            }
            if (!target) {
              // Stray before any section: prepend to the next one.
              target = members.slice(index).find(isSection)!
              const first = target.content?.[0]
              anchor = first ? {key: first._key, position: 'before'} : undefined
            }
            const taken = new Set((target.content ?? []).map((b) => b._key))
            const blockKey = taken.has(member._key) ? snapshot.context.keyGenerator() : member._key
            const value = {...member, _key: blockKey}
            const contentPath: Path = [...variationPath, 'variants', {_key: target._key}, 'content']
            actions.push(raise({type: 'unset', at}))
            actions.push(
              anchor
                ? raise({
                    type: 'insert',
                    at: [...contentPath, {_key: anchor.key}],
                    value,
                    position: anchor.position,
                  })
                : raise({type: 'set', at: contentPath, value: [value]}),
            )
            anchor = {key: blockKey, position: 'after'}
            moved.set(member._key, {sectionKey: target._key, blockKey})
          })
        }

        const selection = snapshot.context.selection
        const remap = (path: Path): Path | undefined => {
          const [variation, field, member, ...rest] = path
          if ((variation as Keyed)?._key !== block._key || field !== 'variants') return undefined
          const to = moved.get((member as Keyed)?._key)
          if (!to) return undefined
          return [
            ...variationPath,
            'variants',
            {_key: to.sectionKey},
            'content',
            {_key: to.blockKey},
            ...rest,
          ]
        }
        const anchorPath = selection && remap(selection.anchor.path)
        const focusPath = selection && remap(selection.focus.path)
        if (selection && anchorPath && focusPath) {
          actions.push(
            raise({
              type: 'select',
              at: {
                anchor: {path: anchorPath, offset: selection.anchor.offset},
                focus: {path: focusPath, offset: selection.focus.offset},
              },
            }),
          )
        }
        return actions
      },
    ],
  })

export function createAudienceVariantBehaviors(types: SectionTypes) {
  return [
    repairVariations(types),
    wrapSelection(types),
    wrapOnShortcut,
    insertWrapsSelection(types),
    scaffoldInsertedVariation(types),
    unwrapVariation,
    addSection(types),
    removeSection,
    convertSection(types),
    setTargeting(types),
  ]
}
